#!/bin/bash

current_path=$(cat current-path.txt)
new_path=$1
echo "Old sys-regles path: '$current_path'" 1>&2
echo "New sys-regles path: '$new_path'" 1>&2

if [ "$current_path" = "$new_path" ]; then
    echo "No change in sys-regles path, no need to change files." 1>&2
    exit 0
fi

# find the files which contain the last hard-coded sys-regles path,
path_files=$(grep -l --include '*.sh'  --include '*.lua' -r "$current_path" . | tr '\n' ' ')
if [ -n "$path_files" ]; then
    # and modify this path in these files
    echo "Modifying .sh files containing current_path '$current_path': $path_files" 1>&2
    perl -i -pe "s{$current_path}{$new_path}" $path_files
else
    echo "No .sh file found containing current_path '$current_path'" 1>&2
fi
echo "Recording the new sh path into 'current-path'" 1>&2
echo $new_path >current-path.txt

