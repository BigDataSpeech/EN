#!/bin/sh

h=/mont/path/de/test
ref=$h/data/test/references/asr
hyp=$h/hyp/asr
res=$h/res/asr
scoring=$h/bin/ne-scoring-gen
scripts=$h/scripts

for d in $hyp/rover s23 s24; do 
  dd=`basename $d`
  echo $d
  echo $dd
  cd $d
  pwd
  for f in *.sgml; do
    echo "fichier " $f
    tt=`basename $f _MPR.sgml`.aref
    echo "reference : " $tt
    echo  "scoring..."
    $scoring -csa $scripts/config.lua $ref/$dd/$tt $f > $res/$dd/`basename $f .sgml`.alg
    echo "extraction..."
    awk 'BEGIN {v=0} {if($1 == "Slot") v=1; if(v) print}' $res/$dd/`basename $f .sgml`.alg > $res/$dd/`basename $f .sgml`.sys
  done
  cd ..
done


echo "calcul score global..."
for d in $hyp/rover s23 s24;  do
  dd=`basename $d`
  global=`fgrep Slot  $res/$dd/*sys | sed 's%[()]%%g' | awk '{e+=$5;t+=$6} END {printf("%6.02f%%\n", e/t*100)}'`
  prec=`fgrep "overall precision"  $res/$dd/*sys | sed 's%[()]%%g' | awk '{e+=$;t+=$6} END {printf("%6.02f%%\n", e/t*100)}'`
  echo $dd "SER global :" $global
done

# P = (C)/(C+S+I)
