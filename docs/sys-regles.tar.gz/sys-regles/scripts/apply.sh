#!/bin/bash

h=/mont/path/de/test
test=$h/data/test/man/test_man_Etape_u8.txt
number=$h/scripts/number-net.sed
hyp=$h/hyp

$h/pers-time.lua  $test | $number > $hyp/test_Etape_MPR.sgml
