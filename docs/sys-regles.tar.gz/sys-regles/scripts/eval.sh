#!/bin/bash

h=/mont/path/de/test
scripts=$h/scripts
scoring=$h/bin/ne-scoring-gen

ref=$h/data/test/references/test_man_Etape_SimplifiedPERS+TIME_u8.sgml

hyp=$h/hyp

# lancer l'évaluation
$scoring $scripts/config.lua $ref $hyp/test_Etape_MPR.sgml
