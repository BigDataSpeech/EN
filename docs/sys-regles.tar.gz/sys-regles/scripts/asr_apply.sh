#!/bin/bash

h=/mont/path/de/test
test=$h/data/test/asr/rover/rover_BFMTV_BFMStory_2011-05-31_175900.txt

number=$h/scripts/number-net.sed
hyp=$h/hyp

$h/pers-time.lua  $test | $number > $hyp/asr/rover/rover_BFMTV_BFMStory_2011-05-31_175900_MPR.sgml


