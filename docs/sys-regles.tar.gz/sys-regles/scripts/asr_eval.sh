#!/bin/bash

h=/mont/path/de/test
scripts=$h/scripts
scoring=$h/bin/ne-scoring-gen

ref=$h/data/test/references/asr/rover/rover_BFMTV_BFMStory_2011-05-31_175900.aref

hyp=$h/hyp

# lancer l'évaluation
echo "evaluation en cours..."
echo $scoring 
$scoring $scripts/config.lua -a $ref $hyp/asr/rover/rover_BFMTV_BFMStory_2011-05-31_175900_MPR.sgml

