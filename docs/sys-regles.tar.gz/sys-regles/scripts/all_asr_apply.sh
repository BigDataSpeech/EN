#!/bin/sh

h=/mont/path/de/test
number=$h/scripts/number-net.sed
data=$h/data/test/asr
hyp=$h/hyp/asr

for d in $data/rover s23  s24 ; do
  dd=`basename $d`
  echo $d
  cd $d
  pwd
  for f in *.txt; do
    echo $f
    ff=`basename $f .txt`_MPR.sgml
    echo $ff
    $h/pers-time.lua $f | $number > $hyp/$dd/$ff
  done
  cd ..
done

