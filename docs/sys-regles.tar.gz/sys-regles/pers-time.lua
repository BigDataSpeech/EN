#!/mont/path/de/test/bin/wmatch

h = "/mon/path/de/test"

paths.rules   = { h.."/regles", h.."/listes"}
paths.dicos   = { h.."/dic" }
paths.filters = { h.."/filtres" }
paths.treetagger = { h.."/dic" }

cache(h.."/compwm")

r = input()

-- POS tag
r = treetagger_semideep(r, "french-par-linux-3.1.bin", "tt-french-mapping.txt")
-- stemming
r = dico_delaf_gram_sem_flex_shallow(r, "stems-fr.txt")

-- analysis numbers
r = match_left_recurse(r, "cardorinaux2.wm")
r = numbers(r)

-- pre-analysis on character level
r = word_tag_full(r, "cl-analysis.wm")

-- dates et heures simples
r = match_global_replace(r, "date-simple.wm")
r = match_global_replace(r, "heure-simple.wm")

-- noms de personne simple
r = match_global_replace(r, "pers-simple.wm")

-- Filtering
r = filter(r, "filt_tmp")
r = filter(r, "filt_tt-fr")
r = filter(r, "virer_stems")


output(r)
