#!/bin/bash

# run from the .../demolab main directory:
# ...change-path.sh

if [ $# -ne 1 ];  then
echo Usage: $0 `pwd` 1>&2
echo Ce script remplace les paths current_path par celui donné en 1>&2
echo Ce programme lit current-path.txt et remplace celui-ci par 1>&2
echo le path donné en entrée. 1>&2
exit 1
fi

./do-change-path.sh "$*"

