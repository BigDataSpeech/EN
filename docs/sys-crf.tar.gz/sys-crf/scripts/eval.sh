#!/bin/bash

h=/mon/path/de/test
wapiti=$h/bin/wapiti
model=$h/models
scripts=$h/scripts

scoring=$h/bin/ne-scoring-gen

test=$h/data/test/man/test_man_Etape_u8.bio
ref=$h/data/test/references/test_man_Etape_SimplifiedPERS+TIME_u8.sgml

hyp=$h/hyp

#tout d'abord, transformer en sgml le fichier bio fourni par wapiti

cat $hyp/test_Etape_MPM.bio | awk -f $scripts/scripts/BIO-to-xml.awk > $hyp/test_Etape_MPM.sgml

#puis lancer l'évaluation
$scoring $scripts/config.lua $ref $hyp/test_Etape_MPM.sgml
