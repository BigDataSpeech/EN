#!/bin/bash

h=/mon/path/de/test
wapiti=$h/bin/wapiti
patrons=$h/patterns/basic-patterns.txt
model=$h/models/mon_premier_model
data=$h/data/test/asr

test=$data/rover/rover_BFMTV_BFMStory_2011-05-31_175900.bio

hyp=$h/hyp/asr/rover

$wapiti label -m $model $test > $hyp/asr/rover/hyp_rover_BFMTV_BFMStory_2011-05-31_175900.bio
