#!/bin/bash

h=/mon/path/de/test
scripts=$h/scripts
scoring=$h/bin/ne-scoring-gen
data=$h/data/test
asr=$data/references/asr

ref=$asr/rover/rover_BFMTV_BFMStory_2011-05-31_175900.aref

hyp=$h/hyp/asr/rover

# transformer bio en xml
echo "transformation en xml..."
cat $hyp/hyp_rover_BFMTV_BFMStory_2011-05-31_175900.bio | awk -f $scripts/BIO-to-xml.awk > $hyp/hyp_rover_BFMTV_BFMStory_2011-05-31_175900_MPR.sgml

# lancer l'évaluation
echo "evaluation en cours..."
echo $scoring 
$scoring $scripts/config.lua -a $ref $hyp/hyp_rover_BFMTV_BFMStory_2011-05-31_175900_MPR.sgml

