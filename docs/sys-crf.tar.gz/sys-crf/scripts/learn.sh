#!/bin/bash

h=/mon/path/de/test
wapiti=$h/bin/wapiti
patrons=$h/patterns/basic-patterns.txt
models=$h/models
trn=$h/data/trn/train_Etape_SimplifiedPERS+TIME_u8.bio

$wapiti train -c -w 0 -a rprop -i 40 -p $patrons $trn $models/mon_premier_model

