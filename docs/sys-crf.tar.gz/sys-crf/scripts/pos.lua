#!/mon/path/de/test/bin/wmatch

h = "/mon/path/de/test/scripts"

paths.treetagger = { h.."/dic" }

r = input()

-- POS tag
r = treetagger_semideep(r, "french-par-linux-3.1.bin", "tt-french-mapping.txt")


output(r)
