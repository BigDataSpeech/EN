#!/bin/sh

h=/mon/path/de/test
wapiti=$h/bin/wapiti
patrons=$h/patterns/basic-patterns.txt
model=$h/models/mon_premier_model
data=$h/data/test/asr
hyp=$h/hyp/asr

for d in $data/rover s23  s24 ; do s25  s30  s35; do
  dd=`basename $d`
  echo $d
  cd $d
  pwd
  for f in *.bio; do
    echo $f
    ff=`basename $f .bio`_MPM.hyp
    echo $ff
    $wapiti label -m $model $f > $hyp/$dd/$ff
  done
  cd ..
done

