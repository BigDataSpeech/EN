#!/bin/sh

h=/mon/path/de/test
ref=$h/data/test/references/asr
hyp=$h/hyp/asr
res=$h/res/asr
scoring=$h/bin/ne-scoring-gen
scripts=$h/scripts

#for d in $hyp/rover s23  s24  s25  s30  s35; do
for d in $hyp/rover s23 s24; do #   s24  s25  s30  s35; do
  dd=`basename $d`
  echo $d
  cd $d
  pwd
  for f in *.hyp; do
  # for f in rover_BFMTV_BFMStory_2011-05-31_175900_MPM.hyp; do
    echo $f
    ff=`basename $f .hyp`.res
    tt=`basename $f _MPM.hyp`.aref
    echo "transformation de l'hypothèse bio en sgml"
    sgml=`basename $f .hyp`.sgml
    cat $f | awk -f $scripts/BIO-to-xml.awk > $sgml
    $scoring -csa $scripts/config.lua $ref/$dd/$tt $sgml > $res/$dd/`basename $f .hyp`.alg
    awk 'BEGIN {v=0} {if($1 == "Slot") v=1; if(v) print}' $res/$dd/`basename $f .hyp`.alg > $res/$dd/`basename $f .hyp`.sys
  done
  cd ..
done


echo "calcul score global..."
for d in $hyp/rover s23 s24; do #s23  s24  s25  s30  s35; do
  dd=`basename $d`
  global=`fgrep Slot  $res/$dd/*sys | sed 's%[()]%%g' | awk '{e+=$5;t+=$6} END {printf("%6.02f%%\n", e/t*100)}'`
  echo $dd "SER global :" $global
done
