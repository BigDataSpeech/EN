#!/bin/bash

h=/mon/path/de/test
wapiti=$h/bin/wapiti
patrons=$h/patterns/basic-patterns.txt
model=$h/models/mon_premier_model
test=$h/data/test/man/test_man_Etape_u8.bio

hyp=$h/hyp/man

$wapiti label -m $model $test > $hyp/man/test_Etape_MPM.bio
