#!/bin/bash

h=/mon/path/de/test
wmatch=/mon/path/de/test/bin/wmatch
trn=$h/data/trn

scripts=$h/scripts

# annotation en POS et mise au format tabulaire
echo "Annotation en POS ..."
cat $trn/train_Etape.txt | $scripts/pos.lua | awk '{for (i=1;i<=NF;i++) print $i; print ""}' | sed -s "s:|: :"  > $trn/train_Etape_POS.bio

# préparation du fichier d'apprentissage format tabulaire pour l'apprentissage
# c'est à dire avec le label de l'entité en colonne 3.

echo "Préparation du fichier trn..."
cd $trn
cat train_Etape_SimplifiedPERS+TIME_u8.bio | awk '{print $2}' > label
paste -d" " train_Etape_POS.bio label > train_Etape_SimplifiedPERS+TIME_POS_u8.bio
